import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import uob.oop.NLP;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class Tester_NLP {

    @Test
    @Order(1)
    void textCleaning(){
        String strTest = "!\"$%&^%H).,e+ll~'/o/Wor.l,d!";
        assertEquals("helloworld", NLP.textCleaning(strTest));
    }

    @Test
    @Order(2)
    void textLemmatization(){
        String strTest = "applesinged and bananas and ending and sorted";
        assertEquals("applesing and banana and end and sort", NLP.textLemmatization(strTest));
    }

    @Test
    @Order(3)
    void textStopWords(){
        String[] stopWords = {"the" , "and", "a" , "at"};
        String strTest = "the simple check to see a great success at this task and what more can the person want";
        assertEquals("simple check to see great success this task what more can person want", NLP.removeStopWords(strTest, stopWords));
    }

}
