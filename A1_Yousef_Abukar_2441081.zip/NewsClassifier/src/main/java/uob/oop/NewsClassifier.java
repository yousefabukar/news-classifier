package uob.oop;

import java.text.DecimalFormat;

public class NewsClassifier {
    public String[] myHTMLs;
    public String[] myStopWords = new String[127];
    public String[] newsTitles;
    public String[] newsContents;
    public String[] newsCleanedContent;
    public double[][] newsTFIDF;

    private final String TITLE_GROUP1 = "Osiris-Rex's sample from asteroid Bennu will reveal secrets of our solar system";
    private final String TITLE_GROUP2 = "Bitcoin slides to five-month low amid wider sell-off";

    public Toolkit myTK;

    public NewsClassifier() {
        myTK = new Toolkit();
        myHTMLs = myTK.loadHTML();
        myStopWords = myTK.loadStopWords();

        loadData();
    }

    public static void main(String[] args) {
        NewsClassifier myNewsClassifier = new NewsClassifier();

        myNewsClassifier.newsCleanedContent = myNewsClassifier.preProcessing();

        myNewsClassifier.newsTFIDF = myNewsClassifier.calculateTFIDF(myNewsClassifier.newsCleanedContent);

        //Change the _index value to calculate similar based on a different news article.
        double[][] doubSimilarity = myNewsClassifier.newsSimilarity(0);

        System.out.println(myNewsClassifier.resultString(doubSimilarity, 10));

        String strGroupingResults = myNewsClassifier.groupingResults(myNewsClassifier.TITLE_GROUP1, myNewsClassifier.TITLE_GROUP2);
        System.out.println(strGroupingResults);

    }

    public void loadData() {
        //TODO 4.1 - 2 marks
        newsTitles = new String[myHTMLs.length];
        newsContents = new String[myHTMLs.length];

        for (int i = 0; i < myHTMLs.length; i++) {
            newsTitles[i] = HtmlParser.getNewsTitle(myHTMLs[i]);
            newsContents[i] = HtmlParser.getNewsContent(myHTMLs[i]);
        }
    }

    public String[] preProcessing() {
        String[] myCleanedContent = null;
        //TODO 4.2 - 5 marks
        myCleanedContent = new String[newsContents.length];
        System.arraycopy(newsContents, 0, myCleanedContent, 0, newsContents.length);
        for (int i = 0; i < myCleanedContent.length; i++) {
            myCleanedContent[i] = NLP.textCleaning(myCleanedContent[i]);
        }
        for (int i = 0; i < myCleanedContent.length; i++) {
            myCleanedContent[i] = NLP.textLemmatization(myCleanedContent[i]);
        }
        for (int i = 0; i < myCleanedContent.length; i++) {
            myCleanedContent[i] = NLP.removeStopWords(myCleanedContent[i], myStopWords);
        }
        return myCleanedContent;
    }

    public double[][] calculateTFIDF(String[] _cleanedContents) {
        String[] vocabularyList = buildVocabulary(_cleanedContents);
        double[][] myTFIDF = null;

        //TODO 4.3 - 10 marks
        myTFIDF = new double[_cleanedContents.length][vocabularyList.length];

        for (int i = 0; i < _cleanedContents.length; i++) {
            String[] splitWords = _cleanedContents[i].split(" ");
            int numberOfWords = splitWords.length;
            // i  loop through cleaned-contents, split into words and count the number of words

            for (int j = 0;  j < vocabularyList.length; j++) {
                String vocabListWord = vocabularyList[j];
                int wordOccurance = 0;
                // loop through vocab list and set the occurance of words as 0

                for (String documentWord : splitWords) {
                    if (documentWord.equals(vocabListWord)) {
                        wordOccurance++;
                        /* loop through words in the document , if it equals a word in the vocab list
                        increment the occurance of that word.
                         */
                    }
                }
                double termFrequency = (double) wordOccurance / numberOfWords;
                myTFIDF[i][j] = termFrequency;
            }

        }
        for (int j = 0; j < vocabularyList.length; j++) {
            String vocabListWord = vocabularyList[j];
            int docsContainingUniqueWord = 0;
            for (int i = 0; i < _cleanedContents.length; i++) {
                String[] splitWords = _cleanedContents[i].split(" ");
                for (String docWords : splitWords) {
                    if (docWords.equals(vocabListWord)) {
                        docsContainingUniqueWord++;
                        break;
                    }
                }
            }
            int numberOfDocuments = _cleanedContents.length;
            double inverseDocumentFrequency = Math.log((double) numberOfDocuments / docsContainingUniqueWord) + 1;

            for (int i = 0; i < _cleanedContents.length; i++) {
                myTFIDF[i][j] = myTFIDF[i][j] * inverseDocumentFrequency;
            }
        }
        return myTFIDF;
    }

    public String[] buildVocabulary(String[] _cleanedContents) {
        String[] arrayVocabulary = null;

        //TODO 4.4 - 10 marks
        String[] uniqueWords = new String[0];
        boolean isEmptyStringAdded = false;
        for (String cleanedContent : _cleanedContents) {
            String[] splitContent = cleanedContent.split(" ");
            for (String word : splitContent) {
                if (word.isEmpty() && !isEmptyStringAdded) {
                    String[] updatedArray = new String[uniqueWords.length + 1];
                    System.arraycopy(uniqueWords, 0, updatedArray, 0, uniqueWords.length);
                    updatedArray[uniqueWords.length] = word;
                    uniqueWords = updatedArray;
                    isEmptyStringAdded = true;
                } else if ((!word.isEmpty() && !contains(uniqueWords, word))) {
                    String[] updatedArray = new String[uniqueWords.length + 1];
                    System.arraycopy(uniqueWords, 0, updatedArray, 0, uniqueWords.length);
                    updatedArray[uniqueWords.length] = word;
                    uniqueWords = updatedArray; {
                    }
                }
            }
        }
        arrayVocabulary = new String[uniqueWords.length];
        System.arraycopy(uniqueWords, 0, arrayVocabulary, 0, uniqueWords.length);
        return arrayVocabulary;
    }

    private static boolean contains(String[] array, String word) {
        for (String forLoopWord : array) {
            if ((forLoopWord == null && word == null) || (forLoopWord != null &&forLoopWord.equals(word))) {
                return true;
            }
        }
        return false;
    }



    public double[][] newsSimilarity(int _newsIndex) {
        double[][] mySimilarity = null;

        //TODO 4.5 - 15 marks
        mySimilarity = new double[newsCleanedContent.length][2];
        newsTFIDF = calculateTFIDF(newsCleanedContent);
        for (int i = 0, j = 0; i < newsCleanedContent.length; i++) {
            double[] tfidfIndex = newsTFIDF[_newsIndex];
            double[] tfidfCurrent = newsTFIDF[i];

            Vector v1 = new Vector(tfidfIndex);
            Vector v2 = new Vector(tfidfCurrent);

            double cosineSimValue = i == _newsIndex ? 1 : v1.cosineSimilarity(v2);
            mySimilarity[j][0] = i;
            mySimilarity[j][1] = cosineSimValue;
            j++;
        } /* calculate the tfidf for newsindex and then calculate
        the cs value between tfidf vector of newsindex and other articles */

        descendingSortMethod(mySimilarity);
        return mySimilarity;
    }
    private void descendingSortMethod(double[][] array) {
        int lengthOfArray = array.length;
        for (int i = 0; i < lengthOfArray - 1; i++) {
            for (int j = 0; j < lengthOfArray - 1 - i; j++) {
                if (array[j][1] < array[j + 1][1]) {
                    double[] swap = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = swap;
                }
            }

        }
    }


    public String groupingResults(String _firstTitle, String _secondTitle) {
        int[] arrayGroup1 = null, arrayGroup2 = null;

        //TODO 4.6 - 15 marks
        int placedInGroup1 = 0;
        int placedInGroup2 = 0;
        arrayGroup1 = new int[newsTitles.length];
        arrayGroup2 = new int[newsTitles.length];
        int firstNewsTitleIndex = -1;
        int secondNewsTitleIndex = -1;

        for (int i = 0; i < newsTitles.length; i++) {
            if (_firstTitle.equals(newsTitles[i])) {
                firstNewsTitleIndex = i;
            }
            if (_secondTitle.equals(newsTitles[i])) {
                secondNewsTitleIndex = i;
            }
            if (firstNewsTitleIndex != -1 && secondNewsTitleIndex != -1) {
                break;
            }
        }

        double[] firstNewsTitleTFIDF = newsTFIDF[firstNewsTitleIndex];
        double[] secondNewsTitleTFIDF = newsTFIDF[secondNewsTitleIndex];

        for (int i = 0; i < newsTitles.length; i++) {
            double[] currentNewsTitleTFIDF = newsTFIDF[i];
            Vector v1 = new Vector(firstNewsTitleTFIDF);
            Vector v2 = new Vector(currentNewsTitleTFIDF);
            double cosineSimilarity1 = v1.cosineSimilarity(v2);

            v1 = new Vector(secondNewsTitleTFIDF);
            double cosineSimilarity2 = v1.cosineSimilarity(v2);

            if (cosineSimilarity1 >= cosineSimilarity2) {
                placedInGroup1++;
            } else {
                placedInGroup2++;
            }
        }
        arrayGroup1 = new int[placedInGroup1];
        arrayGroup2 = new int[placedInGroup2];
        placedInGroup1 = 0;
        placedInGroup2 = 0;

        for (int i = 0; i < newsTitles.length; i++) {
            double[] currentNewsTitleTFIDF = newsTFIDF[i];
            Vector v1 = new Vector(firstNewsTitleTFIDF);
            Vector v2 = new Vector(currentNewsTitleTFIDF);
            double cosineSimilarity1 = v1.cosineSimilarity(v2);

            v1 = new Vector(secondNewsTitleTFIDF);
            double cosineSimilarity2 = v1.cosineSimilarity(v2);

            if (cosineSimilarity1 >= cosineSimilarity2) {
                arrayGroup1[placedInGroup1++] = i;
            } else {
                arrayGroup2[placedInGroup2++] = i;
            }
        }
        return resultString(arrayGroup1, arrayGroup2);
    }

    public String resultString(double[][] _similarityArray, int _groupNumber) {
        StringBuilder mySB = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#.#####");
        for (int j = 0; j < _groupNumber; j++) {
            for (int k = 0; k < _similarityArray[j].length; k++) {
                if (k == 0) {
                    mySB.append((int) _similarityArray[j][k]).append(" ");
                } else {
                    String formattedCS = decimalFormat.format(_similarityArray[j][k]);
                    mySB.append(formattedCS).append(" ");
                }
            }
            mySB.append(newsTitles[(int) _similarityArray[j][0]]).append("\r\n");
        }
        mySB.delete(mySB.length() - 2, mySB.length());
        return mySB.toString();
    }

    public String resultString(int[] _firstGroup, int[] _secondGroup) {
        StringBuilder mySB = new StringBuilder();
        mySB.append("There are ").append(_firstGroup.length).append(" news in Group 1, and ").append(_secondGroup.length).append(" in Group 2.\r\n").append("=====Group 1=====\r\n");

        for (int i : _firstGroup) {
            mySB.append("[").append(i + 1).append("] - ").append(newsTitles[i]).append("\r\n");
        }
        mySB.append("=====Group 2=====\r\n");
        for (int i : _secondGroup) {
            mySB.append("[").append(i + 1).append("] - ").append(newsTitles[i]).append("\r\n");
        }

        mySB.delete(mySB.length() - 2, mySB.length());
        return mySB.toString();
    }

}
