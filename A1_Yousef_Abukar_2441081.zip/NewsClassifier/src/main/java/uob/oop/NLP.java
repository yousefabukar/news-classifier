package uob.oop;



public class NLP {
    /***
     * Clean the given (_content) text by removing all the characters that are not 'a'-'z', '0'-'9' and white space.
     * @param _content Text that need to be cleaned.
     * @return The cleaned text.
     */
    public static String textCleaning(String _content) {
        StringBuilder sbContent = new StringBuilder();
        //TODO Task 2.1 - 3 marks
        _content = _content.toLowerCase();
        char[] newArray = _content.toCharArray();
        for (int i = 0; i < newArray.length; i++) {
            char newCharacter = newArray[i];
            if ((newCharacter >= 'a' && newCharacter <= 'z') || (newCharacter >= '0' && newCharacter <= '9') || newCharacter == ' ') {
                sbContent.append(newCharacter);
            }
        }


        return sbContent.toString().trim();
    }

    /***
     * Text lemmatization. Delete 'ing', 'ed', 'es' and 's' from the end of the word.
     * @param _content Text that need to be lemmatized.
     * @return Lemmatized text.
     */
    public static String textLemmatization(String _content) {
        StringBuilder sbContent = new StringBuilder();
        //TODO Task 2.2 - 3 marks
        String [] words = _content.split(" ");

        for (String word : words) {
            if (word.endsWith("ing")) {
                sbContent.append(word, 0, word.length() - 3);
            } else if (word.endsWith("ed")) {
                sbContent.append(word, 0, word.length() - 2);
            } else if (word.endsWith("es")) {
                sbContent.append(word, 0, word.length() - 2);
            } else if (word.endsWith("s")) {
                sbContent.append(word, 0, word.length() - 1);
            } else {
                sbContent.append(word);
            }
            sbContent.append(" ");
        }


        return sbContent.toString().trim();
    }

    /***
     * Remove stop-words from the text.
     * @param _content The original text.
     * @param _stopWords An array that contains stop-words.
     * @return Modified text.
     */
    public static String removeStopWords(String _content, String[] _stopWords) {
        StringBuilder sbConent = new StringBuilder();
        //TODO Task 2.3 - 3 marks
        String [] contentWords = _content.split(" ");
        for (String stoplessWord : contentWords) {
            boolean isStopword = false;
                for (String stopWord: _stopWords) {
                    if (stoplessWord.equals(stopWord)) {
                        isStopword = true;
                        break;
                    }
                }
                if (!isStopword) {
                    if (!sbConent.isEmpty()) {
                        sbConent.append(' ');
                    }
                    sbConent.append(stoplessWord);
                }
            }

        return sbConent.toString().trim();
    }
}