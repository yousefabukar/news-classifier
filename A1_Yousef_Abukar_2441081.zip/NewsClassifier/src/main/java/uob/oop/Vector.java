package uob.oop;

public class Vector {
    private double[] doubElements;

    public Vector(double[] _elements) {
        //TODO Task 3.1 - 0.5 marks
        this.doubElements = _elements;
    }

    public double getElementatIndex(int _index) {
        //TODO Task 3.2 - 2 marks
        if (_index < doubElements.length && _index >= 0) {
            return doubElements[_index];
        } else {
            return -1.0; //you need to modify the return value
        }
    }

    public void setElementatIndex(double _value, int _index) {
        //TODO Task 3.3 - 2 marks
        if (_index < doubElements.length && _index >= 0) {
            doubElements[_index] = _value;
        } else {
            int lastElement = doubElements.length - 1;
            doubElements[lastElement] = _value;
        }

    }

    public double[] getAllElements() {
        //TODO Task 3.4 - 0.5 marks


        return this.doubElements; //you need to modify the return value
    }

    public int getVectorSize() {
        //TODO Task 3.5 - 0.5 marks

        return doubElements.length; //you need to modify the return value
    }

    public Vector reSize(int _size) {
        //TODO Task 3.6 - 6 marks
        if (_size == doubElements.length || _size <= 0) {
            return this;
        } else if (_size < doubElements.length) {
            double [] arrayX = new double[_size];
            System.arraycopy(doubElements, 0, arrayX, 0, _size);
            return new Vector(arrayX);
        } else {
            double [] arrayX = new double[_size];
            System.arraycopy(doubElements, 0, arrayX, 0, doubElements.length);
            for (int i = doubElements.length; i < _size; i++) {
                arrayX[i] = -1.0;
            }
            return new Vector(arrayX); //you need to modify the return value
        }
    }

    public Vector add(Vector _v) {
        //TODO Task 3.7 - 2 marks
        int vectorLength = Math.max(doubElements.length, _v.doubElements.length);
        if (_v.doubElements.length > doubElements.length) {
           this.doubElements = this.reSize(vectorLength).doubElements;
        } else {
           _v.doubElements = _v.reSize(vectorLength).doubElements;
        }
        for (int i = 0; i < vectorLength; i++) {
            doubElements[i] += _v.doubElements[i];
        }
        return this; //you need to modify the return value
    }

    public Vector subtraction(Vector _v) {
        //TODO Task 3.8 - 2 marks
        int vectorLength1 = Math.max(doubElements.length, _v.doubElements.length);
        if (_v.doubElements.length > doubElements.length) {
            this.doubElements = this.reSize(vectorLength1).doubElements;
        } else {
            _v.doubElements = _v.reSize(vectorLength1).doubElements;
        }
        for (int i = 0; i < vectorLength1; i++) {
            doubElements[i] -= _v.doubElements[i];
        }

        return this; //you need to modify the return value
    }

    public double dotProduct(Vector _v) {
        //TODO Task 3.9 - 2 marks
        int vectorLength2 = Math.max(doubElements.length, _v.doubElements.length);
        Vector resizeOne = this.reSize(vectorLength2);
        Vector resizeTwo = _v.reSize(vectorLength2);

        double result = 0.0;

        for (int i = 0; i < vectorLength2; i++) {
            result += resizeOne.doubElements[i] * resizeTwo.doubElements[i];
        }
        return result; //you need to modify the return value
    }

    public double cosineSimilarity(Vector _v) {
        //TODO Task 3.10 - 6.5 marks
        int vectorLength3 = Math.max(doubElements.length, _v.doubElements.length);
        Vector resizeOne = this.reSize(vectorLength3);
        Vector resizeTwo = _v.reSize(vectorLength3);

        double dotProduct = 0.0;
        double magnitudeOfU = 0.0;
        double magnitudeOfV = 0.0;

        for (int i = 0; i < vectorLength3; i++) {
            dotProduct += resizeOne.doubElements[i] * resizeTwo.doubElements[i];
            magnitudeOfU += resizeOne.doubElements[i] * resizeOne.doubElements[i];
            magnitudeOfV += resizeTwo.doubElements[i] * resizeTwo.doubElements[i];
        }
        return dotProduct/(Math.sqrt(magnitudeOfU)*(Math.sqrt(magnitudeOfV))); //you need to modify the return value
    }

    @Override
    public boolean equals(Object _obj) {
        Vector v = (Vector) _obj;
        boolean boolEquals = true;

        if (this.getVectorSize() != v.getVectorSize())
            return false;

        for (int i = 0; i < this.getVectorSize(); i++) {
            if (this.getElementatIndex(i) != v.getElementatIndex(i)) {
                boolEquals = false;
                break;
            }
        }
        return boolEquals;
    }

    @Override
    public String toString() {
        StringBuilder mySB = new StringBuilder();
        for (int i = 0; i < this.getVectorSize(); i++) {
            mySB.append(String.format("%.5f", doubElements[i])).append(",");
        }
        mySB.delete(mySB.length() - 1, mySB.length());
        return mySB.toString();
    }
}
