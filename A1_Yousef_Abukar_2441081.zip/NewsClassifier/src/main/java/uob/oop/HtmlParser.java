package uob.oop;

public class HtmlParser {
    /***
     * Extract the title of the news from the _htmlCode.
     * @param _htmlCode Contains the full HTML string from a specific news. E.g. 01.htm.
     * @return Return the title if it's been found. Otherwise, return "Title not found!".
     */
    public static String getNewsTitle(String _htmlCode) {
        //TODO Task 1.1 - 5 marks
        String wordStart = "<title>";
        String wordEnd = "</title>";

        int titleBegin = _htmlCode.indexOf(wordStart);
        int titleEnd = _htmlCode.indexOf(wordEnd);

        if (titleEnd != -1 && titleBegin != -1) {
            String titleHeadline = _htmlCode.substring(titleBegin + wordStart.length(), titleEnd);

            if (!titleHeadline.isEmpty()) {
                int straightLine = titleHeadline.indexOf('|');
                if (straightLine != -1) {
                    String extractTitle = titleHeadline.substring(0, straightLine);

                    extractTitle = extractTitle.trim();
                    return extractTitle;
                } else {
                    return titleHeadline;
                }
            }
        }
        return "Title not found!";
    }


    /***
     * Extract the content of the news from the _htmlCode.
     * @param _htmlCode Contains the full HTML string from a specific news. E.g. 01.htm.
     * @return Return the content if it's been found. Otherwise, return "Content not found!".
     */
    public static String getNewsContent(String _htmlCode) {
        //TODO Task 1.2 - 5 marks
        String start = "\"articleBody\": \"";
        String end = "\",\"mainEntityOfPage\"";
        int bodyBegin = _htmlCode.indexOf(start) + start.length();
        int bodyEnd = _htmlCode.indexOf(end);

        if (bodyEnd != -1) {
            String articleBody = _htmlCode.substring(bodyBegin, bodyEnd);
            return articleBody.toLowerCase().trim();
        } else {

            return "Content not found!";
        }
    }
}

